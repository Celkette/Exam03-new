/* power_set1.h */
#ifndef POWER_SET_H
#define POWER_SET_H

/* Prototype de la fonction de backtracking */
void backtrack(int start, int current_sum);

#endif /* POWER_SET_H */