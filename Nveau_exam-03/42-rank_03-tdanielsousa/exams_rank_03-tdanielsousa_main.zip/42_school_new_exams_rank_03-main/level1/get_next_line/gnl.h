#ifndef GNL_H
#define GNL_H

#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h> // testing
#include <stdio.h> // testing

#ifndef BUFFER_SIZE
#define BUFFER_SIZE 32
#endif

#endif
